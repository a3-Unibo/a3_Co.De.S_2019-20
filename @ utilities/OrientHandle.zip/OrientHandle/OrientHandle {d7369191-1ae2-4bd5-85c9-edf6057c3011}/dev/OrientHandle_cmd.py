import rhinoscriptsyntax as rs

__commandname__ = "OrientHandle"


# RunCommand is the called when the user enters the command name in Rhino.
# The command name is defined by the filname minus "_cmd.py"
def RunCommand( is_interactive ):
    objs = rs.GetObjects("Select Objects to orient")
    if objs == None: return 1
    source = rs.GetObject("Select Source handle (L polyline)", rs.filter.curve)
    if source == None: return 1
    sPoly = rs.coercecurve(source)
    receiver = rs.GetObject("Select Receiver handle (L polyline)", rs.filter.curve)
    if receiver == None: return 1
    rPoly = rs.coercecurve(receiver)
    if rs.IsPolyline(sPoly) & rs.IsPolyline(rPoly):
        sPts = ptsFromPolyline(sPoly)
        rPts = ptsFromPolyline(rPoly)
        if sPts ==None or rPts==None: return 1
        for obj in objs:
            rs.OrientObject(obj,sPts,rPts)
  
    # you can optionally return a value from this function
    # to signify command result. Return values that make
    # sense are
    #   0 == success
    #   1 == cancel
    # If this function does not return a value, success is assumed
    return 0

def ptsFromPolyline(poly=None):
    if poly==None:
        return
    pts = rs.PolylineVertices(poly)
    
    if len(pts) != 3:
        return
    newPts = []
    newPts.append(pts[1])
    newPts.append(pts[0])
    newPts.append(pts[2])
    return newPts